package com.signlimit.mixin;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractSignEditScreen.class)
public abstract class AbstractSignEditScreenMixin extends Screen {

    protected AbstractSignEditScreenMixin() {
        super(Text.empty());
    }

    @Shadow private String[] messages;
    @Shadow private int currentRow;
    @Shadow protected abstract void finishEditing();

    @Inject(method = "init", at = @At("TAIL"))
    private void addPasteButton(CallbackInfo ci) {
        // Paste & Done — splits clipboard on newlines across rows
        addDrawableChild(
                ButtonWidget.builder(
                        Text.literal("Paste & Done"),
                        btn -> {
                            String clip = client.keyboard.getClipboard();
                            if (clip != null && !clip.isEmpty()) {
                                String[] lines = clip.split("\n", -1);
                                for (int i = 0; i < messages.length; i++) {
                                    messages[i] = i < lines.length ? lines[i] : "";
                                }
                                currentRow = messages.length - 1;
                            }
                            finishEditing();
                        }
                ).dimensions(width / 2 - 100, height / 4 + 168, 200, 20).build()
        );

        // Paste All Rows & Done — puts the full clipboard string on every row
        addDrawableChild(
                ButtonWidget.builder(
                        Text.literal("Paste All Rows & Done"),
                        btn -> {
                            String clip = client.keyboard.getClipboard();
                            if (clip != null && !clip.isEmpty()) {
                                for (int i = 0; i < messages.length; i++) {
                                    messages[i] = clip;
                                }
                                currentRow = messages.length - 1;
                            }
                            finishEditing();
                        }
                ).dimensions(width / 2 - 100, height / 4 + 192, 200, 20).build()
        );
    }
}