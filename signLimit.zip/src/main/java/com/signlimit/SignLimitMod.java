package com.signlimit;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SignLimitMod implements ModInitializer {

    public static final String MOD_ID = "sign-limit-mod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Sign Limit Mod loaded - Paste & Done button enabled");
    }
}